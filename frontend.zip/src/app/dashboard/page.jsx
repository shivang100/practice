"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function Dashboard() {
  const [resumes, setResumes] = useState([]);
  const router = useRouter();
  const [checkedAuth, setCheckedAuth] = useState(false);

  const fetchResumes = async () => {
    const res = await fetch("http://localhost:8000/resumes");
    setResumes(await res.json());
  };

  useEffect(() => {
    fetchResumes();
  }, []);

  const handleUpload = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    await fetch("http://localhost:8000/upload", {
      method: "POST",
      body: formData,
    });

    e.target.reset();
    fetchResumes();
  };
  const formatIST = (utcDate) => {
    return new Date(utcDate + "Z").toLocaleString("en-IN", {
      timeZone: "Asia/Kolkata",
      dateStyle: "medium",
      timeStyle: "short",
    });
  };

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");

    if (!isLoggedIn) {
      router.replace("/");
    } else {
      setCheckedAuth(true);
    }
  }, [router]);

  // ⛔ Prevent render until auth checked
  if (!checkedAuth) return null;

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    router.push("/");
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8">
      <div className="flex justify-end">
        <button className=" text-red-700" onClick={handleLogout}>
          Logout
        </button>
      </div>
      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        Resume Dashboard 📄
      </h1>

      <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg p-6 mb-8">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">
          Upload Resume
        </h2>

        <form
          onSubmit={handleUpload}
          className="grid gap-4 md:grid-cols-2 justify-center items-center"
        >
          <input
            name="name"
            placeholder="Full Name"
            required
            className="px-4 py-3 rounded-lg border border-gray-300
                       text-gray-900 placeholder-gray-400
                       focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />

          <input
            name="email"
            type="email"
            placeholder="Email Address"
            required
            className="px-4 py-3 rounded-lg border border-gray-300
                       text-gray-900 placeholder-gray-400
                       focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />

          <input
            type="file"
            name="file"
            required
            className="md:col-span-2 px-4 py-2 border rounded-lg bg-white
                       text-gray-700"
          />

          <button
            className="md:col-span-2 bg-indigo-600 hover:bg-indigo-700
                       text-white py-3 rounded-lg font-semibold
                       transition duration-200"
          >
            Upload Resume
          </button>
        </form>
      </div>

      <div className="max-w-5xl mx-auto bg-white rounded-xl shadow-lg p-6 overflow-x-auto">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">
          Uploaded Resumes
        </h2>

        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-200 text-gray-700">
              <th className="p-3 text-left">Name</th>
              <th className="p-3 text-left">Email</th>
              <th className="p-3 text-left">File</th>
              <th className="p-3 text-left">Uploaded At</th>
            </tr>
          </thead>
          <tbody>
            {resumes.map((r) => (
              <tr key={r.id} className="border-t hover:bg-gray-50">
                <td className="p-3 text-gray-800">{r.name}</td>
                <td className="p-3 text-gray-800">{r.email}</td>
                <td className="p-3 text-indigo-600">
                  {r.file_path.split("/").pop()}
                </td>
                <td className="p-3 text-gray-600">
                  {formatIST(r.uploaded_at).toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
